<?php
$cnx = new mysqli('localhost', 'root', '', 'brief9');
// 
